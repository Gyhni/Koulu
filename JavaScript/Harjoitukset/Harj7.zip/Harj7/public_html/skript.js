$(function() {
    $( "#tabs" ).tabs();
  });
