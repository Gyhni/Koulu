function avaa1()
{
    var tekstialue =  document.getElementById("eka");
    
    tekstialue.style.display = "block";
}
function piilota1()
{
    var tekstialue =  document.getElementById("eka");
    
    tekstialue.style.display = "none";
}
function avaa2()
{
    var tekstialue =  document.getElementById("toka");
    
    tekstialue.style.display = "block";
}
function piilota2()
{
    var tekstialue =  document.getElementById("toka");
    
    tekstialue.style.display = "none";
}
function avaa3()
{
    var tekstialue =  document.getElementById("kolmas");
    
    tekstialue.style.display = "block";
}
function piilota3()
{
    var tekstialue =  document.getElementById("kolmas");
    
    tekstialue.style.display = "none";
}
function avaa4()
{
    var tekstialue =  document.getElementById("neljas");
    
    tekstialue.style.display = "block";
}
function piilota4()
{
    var tekstialue =  document.getElementById("neljas");
    
    tekstialue.style.display = "none";
}
function avaa5()
{
    var tekstialue =  document.getElementById("viides");
    
    tekstialue.style.display = "block";
}
function piilota5()
{
    var tekstialue =  document.getElementById("viides");
    
    tekstialue.style.display = "none";
}